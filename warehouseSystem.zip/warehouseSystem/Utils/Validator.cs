﻿using System.Text.RegularExpressions;

namespace WarehouseSystem.Utils
{
    public static class Validator
    {
        // Validates names (letters and spaces, at least 3 characters)
        public static bool ValidName(string input)
        {
            return Regex.IsMatch(input, @"^[a-zA-Z\s]{3,}$");
        }
    }
}

