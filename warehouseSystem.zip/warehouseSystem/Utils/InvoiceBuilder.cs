﻿using System.Text;
using WarehouseSystem.Models;

namespace WarehouseSystem.Utils
{
    public static class InvoiceBuilder
    {
        public static string Build(Order order)
        {
            StringBuilder sb = new();
            sb.AppendLine("=== INVOICE ===");
            sb.AppendLine($"Customer: {order.CustomerName}");
            sb.AppendLine($"Date: {order.Date}");
            sb.AppendLine("------------------------");

            foreach (var item in order.Items)
            {
                sb.AppendLine($"{item.Product.Name} x{item.Quantity} = {item.Total}");
            }

            sb.AppendLine("------------------------");
            sb.AppendLine($"TOTAL: {order.Total}");
            sb.AppendLine("========================");
            return sb.ToString();
        }
    }
}
