﻿using System;
using WarehouseSystem.Models;
using WarehouseSystem.Data;
using WarehouseSystem.Utils;

namespace WarehouseSystem.Services
{
    public static class CategoryService
    {
        public static void Add()
        {
            Console.Write("Category Name: ");
            string name = Console.ReadLine();

            if (!Validator.ValidName(name))
                throw new Exception("Invalid name");

            DataStore.Categories.Add(new Category
            {
                Id = DataStore.Categories.Count + 1,
                Name = name
            });
        }
    }
}
