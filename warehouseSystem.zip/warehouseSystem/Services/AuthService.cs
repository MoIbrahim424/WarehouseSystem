﻿using System;
using System.Linq;
using WarehouseSystem.Models;
using WarehouseSystem.Data;

namespace WarehouseSystem.Services
{
    public static class AuthService
    {
        public static User Login()
        {
            Console.Write("Username: ");
            string u = Console.ReadLine();
            Console.Write("Password: ");
            string p = Console.ReadLine();

            var user = DataStore.Users
                .FirstOrDefault(x => x.Username == u && x.Password == p);

            if (user == null)
                throw new Exception("Login failed");

            return user;
        }
    }
}
