﻿using System;
using System.Linq;
using WarehouseSystem.Models;
using WarehouseSystem.Data;
using WarehouseSystem.Utils;

namespace WarehouseSystem.Services
{
    public static class ReportService
    {
        public static void MonthlyReport()
        {
            Console.Write("Month (1-12): ");
            int m = int.Parse(Console.ReadLine());
            Console.Write("Year: ");
            int y = int.Parse(Console.ReadLine());

            var orders = DataStore.Orders
                .Where(o => o.Date.Month == m && o.Date.Year == y);

            Console.WriteLine($"Total Orders: {orders.Count()}");
            Console.WriteLine($"Total Profit: {orders.Sum(o => o.Total)}");
        }

        public static void CustomerInvoices()
        {
            Console.Write("Customer Name: ");
            string name = Console.ReadLine();

            var orders = DataStore.Orders
                .Where(o => o.CustomerName == name);

            foreach (var o in orders)
                Console.WriteLine(InvoiceBuilder.Build(o));
        }
    }
}
