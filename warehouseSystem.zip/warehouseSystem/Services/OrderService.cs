﻿using System;
using System.Linq;
using WarehouseSystem.Models;
using WarehouseSystem.Data;
using WarehouseSystem.Interfaces;
using WarehouseSystem.Utils;

namespace WarehouseSystem.Services
{
    public static class OrderService
    {
        public static void CreateOrder()
        {
            Order order = new Order
            {
                Id = DataStore.Orders.Count + 1,
                Date = DateTime.Now
            };

            Console.Write("Customer Name: ");
            order.CustomerName = Console.ReadLine();

            while (true)
            {
                Console.Write("Product Id (0 to finish): ");
                int pid = int.Parse(Console.ReadLine());
                if (pid == 0) break;

                var product = DataStore.Products.First(p => p.Id == pid);

                Console.Write("Quantity: ");
                int q = int.Parse(Console.ReadLine());

                if (q > product.Stock)
                    throw new Exception("Not enough stock!");

                product.Stock -= q;

                order.Items.Add(new OrderItem
                {
                    Product = product,
                    Quantity = q
                });
            }

            IPayment payment = new CashPayment();
            payment.Pay(order.Total);

            Console.WriteLine(InvoiceBuilder.Build(order));
            DataStore.Orders.Add(order);
        }
    }
}
