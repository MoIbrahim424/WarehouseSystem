﻿using System;
using WarehouseSystem.Models;
using WarehouseSystem.Data;

namespace WarehouseSystem.Services
{
    public static class ProductService
    {
        public static void Add()
        {
            Console.Write("Product Name: ");
            string name = Console.ReadLine();

            Console.Write("Price: ");
            decimal price = decimal.Parse(Console.ReadLine());

            Console.Write("Stock: ");
            int stock = int.Parse(Console.ReadLine());

            Console.Write("Category Id: ");
            int cat = int.Parse(Console.ReadLine());

            DataStore.Products.Add(new Product
            {
                Id = DataStore.Products.Count + 1,
                Name = name,
                Price = price,
                Stock = stock,
                CategoryId = cat
            });
        }
    }
}
