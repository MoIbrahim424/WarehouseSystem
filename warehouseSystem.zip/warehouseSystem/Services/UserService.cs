﻿using System;
using WarehouseSystem.Models;
using WarehouseSystem.Data;

namespace WarehouseSystem.Services
{
    public static class UserService
    {
        public static void Add()
        {
            Console.Write("Username: ");
            string u = Console.ReadLine();

            Console.Write("Password: ");
            string p = Console.ReadLine();

            Console.Write("Role (0 Admin / 1 Employee): ");
            UserRole r = (UserRole)int.Parse(Console.ReadLine());

            DataStore.Users.Add(new User
            {
                Username = u,
                Password = p,
                Role = r
            });
        }
    }
}
