﻿namespace WarehouseSystem.Models
{
    public enum UserRole { Admin, Employee }

    public sealed class User
    {
        public string Username { get; set; }
        public string Password { get; set; }
        public UserRole Role { get; set; }
    }
}
