﻿namespace WarehouseSystem.Models
{
    public struct Money
    {
        public decimal Amount;
        public string Currency;
    }
}

