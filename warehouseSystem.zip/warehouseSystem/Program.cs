﻿using System;
using WarehouseSystem.Services;
using WarehouseSystem.Models;
using WarehouseSystem.Data;

namespace WarehouseSystem
{
    class Program
    {
        static void Main()
        {
            DataStore.LoadAll();
            Console.WriteLine("=== Warehouse Management System ===");

            try
            {
                var user = AuthService.Login();
                Console.Clear();
                Console.WriteLine($"Welcome {user.Username} ({user.Role})");

                if (user.Role == UserRole.Admin)
                    AdminMenu();
                else
                    EmployeeMenu();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            DataStore.SaveAll();
        }

        static void AdminMenu()
        {
            while (true)
            {
                Console.WriteLine("\n1- Add Category");
                Console.WriteLine("2- Add Product");
                Console.WriteLine("3- Add User");
                Console.WriteLine("4- Monthly Report");
                Console.WriteLine("0- Exit");

                switch (Console.ReadLine())
                {
                    case "1": CategoryService.Add(); break;
                    case "2": ProductService.Add(); break;
                    case "3": UserService.Add(); break;
                    case "4": ReportService.MonthlyReport(); break;
                    case "0": return;
                }
            }
        }

        static void EmployeeMenu()
        {
            while (true)
            {
                Console.WriteLine("\n1- Create Order (POS)");
                Console.WriteLine("2- Customer Invoices");
                Console.WriteLine("0- Exit");

                switch (Console.ReadLine())
                {
                    case "1": OrderService.CreateOrder(); break;
                    case "2": ReportService.CustomerInvoices(); break;
                    case "0": return;
                }
            }
        }
    }
}
