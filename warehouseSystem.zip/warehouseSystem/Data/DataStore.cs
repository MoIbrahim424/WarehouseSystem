﻿using System.Collections.Generic;
using System.IO;
using System.Text.Json;
using System.Linq;
using WarehouseSystem.Models;

namespace WarehouseSystem.Data
{
    public static class DataStore
    {
        public static List<User> Users = new();
        public static List<Category> Categories = new();
        public static List<Product> Products = new();
        public static List<Order> Orders = new();

        static string path = "data";

        public static void LoadAll()
        {
            Directory.CreateDirectory(path);
            Users = Load<User>("users.json");
            Categories = Load<Category>("categories.json");
            Products = Load<Product>("products.json");
            Orders = Load<Order>("orders.json");

            if (!Users.Any())
                Users.Add(new User { Username = "admin", Password = "admin", Role = Models.UserRole.Admin });
        }

        public static void SaveAll()
        {
            Save("users.json", Users);
            Save("categories.json", Categories);
            Save("products.json", Products);
            Save("orders.json", Orders);
        }

        static List<T> Load<T>(string file)
        {
            string f = Path.Combine(path, file);
            if (!File.Exists(f)) return new();
            return JsonSerializer.Deserialize<List<T>>(File.ReadAllText(f)) ?? new List<T>();
        }

        static void Save<T>(string file, List<T> data)
        {
            File.WriteAllText(Path.Combine(path, file),
                JsonSerializer.Serialize(data, new JsonSerializerOptions { WriteIndented = true }));
        }
    }
}

