﻿namespace WarehouseSystem.Interfaces
{
    public interface IPurchasable
    {
        decimal Price { get; set; }
    }
}

