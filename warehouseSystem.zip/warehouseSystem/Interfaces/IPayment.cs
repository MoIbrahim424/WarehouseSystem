﻿namespace WarehouseSystem.Interfaces
{
    public interface IPayment
    {
        void Pay(decimal amount);
    }

    public class CashPayment : IPayment
    {
        public void Pay(decimal amount)
        {
            Console.WriteLine($"Paid in cash: {amount}");
        }
    }
}

